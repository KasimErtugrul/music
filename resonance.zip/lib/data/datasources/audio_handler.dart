import 'dart:async';
import 'package:audio_service/audio_service.dart';
import 'package:just_audio/just_audio.dart';
import 'package:rxdart/rxdart.dart';
import 'package:resonance/data/datasources/audio_session_datasource.dart';
import 'package:resonance/data/datasources/player_datasource.dart';

class ResonanceAudioHandler extends BaseAudioHandler with SeekHandler {
  ResonanceAudioHandler({
    required this._source,
    required this._artResolver,
  }) {
    AudioSessionDatasource(_source).init();
    _bindStreams();
  }

  final PlayerDataSource _source;
  final Future<Uri?> Function(String songUri) _artResolver;
  AudioPlayer get _player => _source.player;

  Stream<Duration> get positionStream => _source.positionStream;
  Stream<Duration?> get durationStream => _source.durationStream;
  Stream<PlayerException> get errorStream => _source.errorStream;
  Duration get position => _source.position;
  int? get currentIndex => _source.currentIndex;
  bool get hasNext => _source.hasNext;
  bool get hasPrevious => _source.hasPrevious;

  void _bindStreams() {
    _source.currentIndexStream.listen((index) async {
      if (index == null) return;
      final items = queue.value;
      if (index >= 0 && index < items.length) {
        final item = items[index];
        mediaItem.add(item);
        
        final artUri = await _artResolver(item.id);
        if (artUri != null && mediaItem.value?.id == item.id) {
          mediaItem.add(item.copyWith(artUri: artUri));
        }
      }
    });

    Rx.merge([
      _source.playbackEventStream,
      _source.loopModeStream.switchMap((_) => _source.playbackEventStream),
      _source.shuffleModeEnabledStream.switchMap((_) => _source.playbackEventStream),
    ]).cast<PlaybackEvent>().listen((event) {
      playbackState.add(_transformEvent(event));
    });

    _source.errorStream.listen((e) {});
  }

  PlaybackState _transformEvent(PlaybackEvent event) {
    final controls = <MediaControl>[
      MediaControl.skipToPrevious,
      _player.playing ? MediaControl.pause : MediaControl.play,
      MediaControl.skipToNext,
    ];

    final repeatMode = switch (_player.loopMode) {
      LoopMode.off => AudioServiceRepeatMode.none,
      LoopMode.one => AudioServiceRepeatMode.one,
      LoopMode.all => AudioServiceRepeatMode.all,
    };
    final shuffleMode = _player.shuffleModeEnabled 
        ? AudioServiceShuffleMode.all 
        : AudioServiceShuffleMode.none;

    return PlaybackState(
      controls: controls,
      systemActions: const {MediaAction.seek, MediaAction.skipToNext, MediaAction.skipToPrevious},
      androidCompactActionIndices: const [0, 1, 2],
      processingState: _mapProcessingState(_player.processingState),
      playing: _player.playing,
      updatePosition: _player.position,
      bufferedPosition: _player.bufferedPosition,
      speed: _player.speed,
      queueIndex: _player.currentIndex,
      repeatMode: repeatMode,
      shuffleMode: shuffleMode,
    );
  }

  AudioProcessingState _mapProcessingState(ProcessingState state) {
    switch (state) {
      case ProcessingState.idle: return AudioProcessingState.idle;
      case ProcessingState.loading: return AudioProcessingState.loading;
      case ProcessingState.buffering: return AudioProcessingState.buffering;
      case ProcessingState.ready: return AudioProcessingState.ready;
      case ProcessingState.completed: return AudioProcessingState.completed;
    }
  }

  Future<void> loadTracks({required List<MediaItem> items, required List<AudioSource> sources, int initialIndex = 0, Duration? initialPosition}) async {
    queue.add(items);
    if (items.isEmpty) {
      mediaItem.add(null);
      return;
    }
    mediaItem.add(items[initialIndex.clamp(0, items.length - 1)]);
    await _source.loadQueue(sources, initialIndex: initialIndex, initialPosition: initialPosition);
  }

  Future<void> insertTrack(int index, MediaItem item, AudioSource source) async {
    final newQueue = queue.value.toList()..insert(index, item);
    queue.add(newQueue);
    await _source.insertSource(index, source);
  }

  Future<void> removeTrack(int index) async {
    final newQueue = queue.value.toList()..removeAt(index);
    queue.add(newQueue);
    await _source.removeSource(index);
  }

  Future<void> moveTrack(int from, int to) async {
    final newQueue = queue.value.toList();
    final item = newQueue.removeAt(from);
    newQueue.insert(to, item);
    queue.add(newQueue);
    await _source.moveSource(from, to);
  }

  @override
  Future<void> play() => _source.play();
  @override
  Future<void> pause() => _source.pause();
  /// Uygulama son uygulamalardan kapatıldığında çağrılır (BaseAudioHandler'da varsayılanı
  /// boştur, bu yüzden kart sonsuza dek kalıyordu). Müzik çalıyorsa devam eder; duraklatılmış
  /// ya da durmuşsa servis ve bildirim kapanır. Her durumda kapatmak için koşulu kaldırıp
  /// doğrudan `await stop();` yazın.
  @override
  Future<void> onTaskRemoved() async {
    if (!_player.playing) await stop();
  }

  @override
  Future<void> stop() async {
    await _source.stop();
    await super.stop();
  }
  @override
  Future<void> seek(Duration position) => _source.seek(position);
  @override
  Future<void> skipToNext() => _source.skipToNext();
  @override
  Future<void> skipToPrevious() => _source.skipToPrevious();
  
  // BaseAudioHandler'da override edilmesi gerekmeyenler
  Future<void> setVolume(double volume) => _source.setVolume(volume);
  Future<void> setPitch(double pitch) => _source.setPitch(pitch);
  Future<void> setSkipSilenceEnabled(bool enabled) => _source.setSkipSilenceEnabled(enabled);

  @override
  Future<void> setSpeed(double speed) => _source.setSpeed(speed);
  
  @override
  Future<void> setShuffleMode(AudioServiceShuffleMode shuffleMode) async {
    await _source.setShuffleModeEnabled(shuffleMode == AudioServiceShuffleMode.all);
  }
  
  @override
  Future<void> setRepeatMode(AudioServiceRepeatMode repeatMode) async {
    final mode = switch (repeatMode) {
      AudioServiceRepeatMode.none => LoopMode.off,
      AudioServiceRepeatMode.one => LoopMode.one,
      AudioServiceRepeatMode.all || AudioServiceRepeatMode.group => LoopMode.all,
    };
    await _source.setLoopMode(mode);
  }
}